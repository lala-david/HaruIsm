import React, {useState} from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  TextInput,
  Image,
} from 'react-native';
import moment from 'moment';
import 'moment/locale/ko'; // 한글 로캘 추가

export default function TodoScreen() {
  const [currentDate, setCurrentDate] = useState(moment());

  const [todos, setTodos] = useState([]);
  const [todoText, setTodoText] = useState('');
  const [editingTodoId, setEditingTodoId] = useState('');
  const [showTextInput, setShowTextInput] = useState(false);
  const [editingTodoText, setEditingTodoText] = useState('');

  const handlePrevWeek = () => {
    setCurrentDate(moment(currentDate).subtract(7, 'days'));
  };

  const handleNextWeek = () => {
    setCurrentDate(moment(currentDate).add(7, 'days'));
  };

  const addTodo = () => {
    if (todoText.trim() !== '') {
      const newTodo = {
        id: Date.now().toString(),
        date: currentDate.format('YYYY-MM-DD'),
        text: todoText,
        completed: false,
      };
      setTodos([...todos, newTodo]);
      setTodoText('');
      setShowTextInput(false);
    }
  };

  const editTodo = (id, newText) => {
    const updatedTodos = todos.map(todo => {
      if (todo.id === id) {
        return {...todo, text: newText};
      }
      return todo;
    });
    setTodos(updatedTodos);
    setEditingTodoId('');
    setEditingTodoText('');
  };

  const deleteTodo = id => {
    const updatedTodos = todos.filter(todo => todo.id !== id);
    setTodos(updatedTodos);
  };

  const toggleTodo = id => {
    const updatedTodos = todos.map(todo => {
      if (todo.id === id) {
        return {...todo, completed: !todo.completed};
      }
      return todo;
    });
    setTodos(updatedTodos);
  };

  const renderCalendarItem = date => {
    const isActive = date.isSame(currentDate, 'day');
    const isPast = date.isBefore(moment(), 'day');
    const hasTodo = todos.some(todo => todo.date === date.format('YYYY-MM-DD'));

    const calendarItemStyles = [
      styles.calendarItem,
      isActive && styles.activeCalendarItem,
      isPast && styles.pastCalendarItem,
      hasTodo && styles.hasTodo,
    ];

    return (
      <TouchableOpacity
        key={date.format('YYYY-MM-DD')}
        style={calendarItemStyles}
        onPress={() => setCurrentDate(date)}>
        <Text style={styles.calendarItemText}>{date.format('D')}</Text>
      </TouchableOpacity>
    );
  };

  const renderCalendar = () => {
    const weekStart = moment(currentDate).startOf('week');
    const daysOfWeek = ['일', '월', '화', '수', '목', '금', '토'];

    const calendarItems = [];
    for (let i = 0; i < 7; i++) {
      const date = moment(weekStart).add(i, 'days');
      const dayOfWeek = daysOfWeek[i];
      calendarItems.push(
        <View key={date.format('YYYY-MM-DD')} style={styles.calendarItem}>
          <Text style={styles.Day_week}>{dayOfWeek}</Text>
          <TouchableOpacity
            style={[
              styles.dateContainer,
              date.isSame(currentDate, 'day') && styles.activeDateContainer,
              todos.some(todo => todo.date === date.format('YYYY-MM-DD')) &&
                styles.hasTodoDateContainer,
            ]}
            onPress={() => setCurrentDate(date)}>
            <Text
              style={[
                styles.dateText,
                date.isSame(currentDate, 'day') && styles.activeDateText,
              ]}>
              {date.format('D')}
            </Text>
          </TouchableOpacity>
        </View>,
      );
    }

    return <View style={styles.calendar}>{calendarItems}</View>;
  };

  const renderTodos = () => {
    const filteredTodos = todos.filter(
      todo => todo.date === currentDate.format('YYYY-MM-DD'),
    );

    return filteredTodos.map(todo => {
      if (editingTodoId === todo.id) {
        return (
          <View key={todo.id} style={styles.todoItem}>
            <TextInput
              style={styles.editInput2}
              value={editingTodoText}
              onChangeText={text => setEditingTodoText(text)}
              autoFocus
              onBlur={() => {
                editTodo(todo.id, editingTodoText); // 수정된 editingTodoText를 사용하여 editTodo 호출
                setEditingTodoId('');
                setEditingTodoText('');
              }}
            />
            <TouchableOpacity
              onPress={() => {
                editTodo(todo.id, editingTodoText); // 수정된 editingTodoText를 사용하여 editTodo 호출
                setEditingTodoId('');
                setEditingTodoText('');
              }}>
              <Text style={styles.save_text}>저장</Text>
            </TouchableOpacity>
          </View>
        );
      }

      return (
        <View key={todo.id} style={styles.todoItem}>
          <TouchableOpacity onPress={() => toggleTodo(todo.id)}>
            {/* 체크박스 표시 */}
            <View style={styles.checkbox}>
              {todo.completed && <View style={styles.checkmark} />}
            </View>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => {
              setEditingTodoId(todo.id);
              setEditingTodoText(todo.text); // 현재 todo의 텍스트로 editingTodoText 설정
            }}>
            <Text
              style={todo.completed ? styles.completedText : styles.todoText}>
              {todo.text}
            </Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => deleteTodo(todo.id)}>
            <View style={styles.delview}>
              <Text style={styles.deltext}>삭제</Text>
            </View>
          </TouchableOpacity>
        </View>
      );
    });
  };

  const renderAddTodoTextInput = () => {
    if (!showTextInput) {
      return (
        <TouchableOpacity
          style={styles.addButton}
          onPress={() => setShowTextInput(true)}>
          <Text style={styles.addButtonText}>할일 등록</Text>
        </TouchableOpacity>
      );
    }

    return (
      <View style={styles.todoItem}>
        <TextInput
          style={styles.editInput}
          placeholder="Enter a todo"
          value={todoText}
          onChangeText={text => setTodoText(text)}
          autoFocus
        />
        <TouchableOpacity style={styles.addButton2} onPress={addTodo}>
          <Text style={styles.addButtonText}>Save</Text>
        </TouchableOpacity>
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={handlePrevWeek}>
          <Text style={styles.left_month_button}>{'<'}</Text>
        </TouchableOpacity>
        <Text style={styles.month}>
          {currentDate.format('YYYY')}년 {currentDate.format('MMMM')}
        </Text>
        <TouchableOpacity onPress={handleNextWeek}>
          <Text style={styles.rigit_month_button}>{'>'}</Text>
        </TouchableOpacity>
      </View>
      {renderCalendar()}
      {renderAddTodoTextInput()}
      <View style={styles.todoList}>{renderTodos()}</View>
      <Image
        style={styles.icon1}
        resizeMode="cover"
        source={require('../../assets/img/aaa.png')}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  month: {
    right: 130,
    paddingTop: 30,
    fontSize: 20,
  },
  todo: {
    color: 'black',
    fontSize: 18,
  },
  calendar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  calendarItem: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
  },
  activeCalendarItem: {
    borderBottomColor: 'blue',
  },
  pastCalendarItem: {
    opacity: 0.5,
  },
  hasTodo: {
    backgroundColor: 'lightblue',
  },
  calendarItemText: {
    fontSize: 16,
  },
  input: {
    height: 5,
    borderWidth: 1,
    borderColor: 'gray',
    marginBottom: 10,
    paddingHorizontal: 10,
  },
  addButton: {
    backgroundColor: '#9cd6e5',
    paddingVertical: 10,
    paddingHorizontal: 23,
    borderRadius: 105,
    marginBottom: 10,
    bottom: 10,
    left: 20,
    width: 330,
  },
  addButton2: {
    backgroundColor: '#9cd6e5',
    paddingVertical: 10,
    paddingHorizontal: 23,
    borderRadius: 105,
    marginBottom: 10,
    bottom: 25,
    right: 10,
  },
  addButtonText: {
    borderRadius: 50,
    fontWeight: 'bold',
    fontSize: 16,
    color: 'white',
    textAlign: 'center',
  },
  todoList: {
    bottom: 5,
    elevation: 20,
    backgroundColor: '#fff',
    width: 370,
    height: 250,
    borderRadius: 20,
  },
  todoItem: {
    top: 20,
    left: 30,
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 15,
  },
  editInput: {
    right: 20,
    bottom: 30,
    height: 35,
    width: 270,
    flex: 0,
    fontSize: 13,
    borderWidth: 1,
    borderColor: 'gray',
    paddingHorizontal: 10,
  },
  editInput2: {
    height: 35,
    width: 270,
    flex: 0,
    fontSize: 13,
    borderWidth: 1,
    borderColor: 'gray',
    paddingHorizontal: 10,
  },
  todoText: {
    flex: 1,
    fontSize: 15,
  },
  completedText: {
    flex: 1,
    fontSize: 15,
    textDecorationLine: 'line-through',
    color: 'gray',
  },
  hasTodoDateContainer: {
    borderRadius: 100,
    width: 40,
    backgroundColor: '#9cd6e5',
  },
  checkbox: {
    width: 20,
    height: 20,
    borderRadius: 2,
    borderWidth: 2,
    borderColor: '#999',
    marginRight: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  checkmark: {
    width: 12,
    height: 12,
    backgroundColor: '#F7CB7F',
  },
  dateContainer: {
    top: 5,
    alignItems: 'center',
    paddingVertical: 10,
  },
  activeDateContainer: {
    borderRadius: 100,
    width: 40,
    backgroundColor: '#1c7892',
  },
  activeDateText: {
    fontWeight: 'bold',
    color: 'white',
  },
  rigit_month_button: {
    top: 17,
    right: 20,
    fontWeight: 'bold',
  },
  left_month_button: {
    top: 17,
    left: 300,
    fontWeight: 'bold',
  },
  deltext: {
    fontWeight: 'bold',
    fontSize: 13,
  },
  delview: {
    left: 10,
  },
  icon1: {
    top: 15,
    left: 125,
    width: 115,
    height: 117,
  },
  save_text: {
    marginLeft: 10,
  },
  Day_week: {
    color: '#1C7892',
  },
});
