import React from 'react';
import {View, Text} from 'react-native';

const Friend = () => {
  return (
    <View>
      <Text>Friend</Text>
    </View>
  );
};

export default Friend;
