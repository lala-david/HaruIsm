import React from 'react';
import {View, Text} from 'react-native';

const Info = () => {
  return (
    <View>
      <Text>info</Text>
    </View>
  );
};

export default Info;
