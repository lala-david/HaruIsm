import React from 'react';
import {View, Text} from 'react-native';

const Account = () => {
  return (
    <View>
      <Text>Account</Text>
    </View>
  );
};

export default Account;
