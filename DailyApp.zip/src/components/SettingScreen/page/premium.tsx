import React from 'react';
import {View, Text} from 'react-native';

const Premium = () => {
  return (
    <View>
      <Text>Premium</Text>
    </View>
  );
};

export default Premium;
