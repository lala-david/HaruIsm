import React from 'react';
import {View, Text} from 'react-native';

const Alarm = () => {
  return (
    <View>
      <Text>Alarm</Text>
    </View>
  );
};

export default Alarm;
