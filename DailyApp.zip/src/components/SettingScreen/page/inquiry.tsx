import React from 'react';
import {View, Text} from 'react-native';

const Inquiry = () => {
  return (
    <View>
      <Text>inquiry</Text>
    </View>
  );
};

export default Inquiry;
