import React from 'react';
import {View, Text} from 'react-native';

const Announcement = () => {
  return (
    <View>
      <Text>Announcement</Text>
    </View>
  );
};

export default Announcement;
