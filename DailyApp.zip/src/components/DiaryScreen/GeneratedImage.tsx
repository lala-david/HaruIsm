import React from 'react';
import {View, Image, Button, StyleSheet, Share} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {RootStackParamList} from '../../types/types';
import {StackNavigationProp} from '@react-navigation/stack';
import {RouteProp} from '@react-navigation/native';

type GeneratedImageScreenProp = StackNavigationProp<
  RootStackParamList,
  'GeneratedImage'
>;

type GeneratedImageProps = {
  route: RouteProp<RootStackParamList, 'GeneratedImage'>;
  navigation: GeneratedImageScreenProp;
};

const GeneratedImage: React.FC<GeneratedImageProps> = ({route, navigation}) => {
  const {image} = route.params;

  const handleSave = async () => {
    const today = new Date();
    const dateString = `${today.getFullYear()}-${String(
      today.getMonth() + 1,
    ).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
    await AsyncStorage.setItem(`${dateString}-image`, image);
  };

  const handleBack = () => {
    navigation.goBack();
  };

  const handleShare = async () => {
    try {
      await Share.share({
        message: `data:image/png;base64,${image}`,
        url: `data:image/png;base64,${image}`,
      });
    } catch (error) {
      console.error('Error sharing image:', error);
    }
  };

  return (
    <View style={styles.container}>
      <Image
        source={{uri: `data:image/png;base64,${image}`}}
        style={styles.image}
      />
      <View style={styles.buttonsContainer}>
        <Button title="뒤로가기" onPress={handleBack} />
        <Button title="저장" onPress={handleSave} />
        <Button title="공유하기" onPress={handleShare} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  image: {
    width: '100%',
    height: '80%',
    resizeMode: 'contain',
  },
  buttonsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
    paddingHorizontal: 16,
    marginTop: 8,
  },
});

export default GeneratedImage;
