import React, {useState, useEffect} from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Image,
  TouchableOpacity,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {RootStackParamList} from '../../types/types';
import {RouteProp} from '@react-navigation/native';
import {DeviceEventEmitter} from 'react-native';

type GalleryProps = {
  route: RouteProp<RootStackParamList, 'Gallery'>;
};

interface ImageItem {
  id: number;
  data: string;
}

export const eventEmitter = DeviceEventEmitter;

const Gallery: React.FC<GalleryProps> = ({route}) => {
  const [images, setImages] = useState<ImageItem[]>([]);
  const selectedDateTag = route.params.tag;

  useEffect(() => {
    const loadImages = async () => {
      const loadedImages = [];
      for (let i = 1; i <= 5; i++) {
        const image = await AsyncStorage.getItem(
          `image-${selectedDateTag}-${i}`,
        );
        if (image) {
          loadedImages.push({id: i, data: image});
        }
      }
      setImages(loadedImages);
    };
    loadImages();
  }, [selectedDateTag]);

  const handleImageDoublePress = async (image: ImageItem) => {
    console.log(`Image ${image.id} double clicked.`);

    const today = new Date();
    const dateString = `${today.getFullYear()}-${String(
      today.getMonth() + 1,
    ).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;

    await AsyncStorage.setItem(`${dateString}-image`, image.data);
    eventEmitter.emit('imageChanged', dateString);
  };

  let lastImageClicked: {id: number; time: Date} | null = null;
  const handleClick = (image: ImageItem) => {
    const now = new Date();
    if (
      lastImageClicked &&
      image.id === lastImageClicked.id &&
      now.valueOf() - lastImageClicked.time.valueOf() < 300
    ) {
      handleImageDoublePress(image);
    }
    lastImageClicked = {id: image.id, time: now};
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>🌌 일기 그림</Text>
      <ScrollView contentContainerStyle={styles.imageScroll}>
        {images.map(image => (
          <TouchableOpacity key={image.id} onPress={() => handleClick(image)}>
            <Image
              source={{uri: `data:image/png;base64,${image.data}`}}
              style={styles.image}
            />
          </TouchableOpacity>
        ))}
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 24,
    marginBottom: 8,
  },
  imageScroll: {
    paddingHorizontal: 8,
  },
  image: {
    width: 200,
    height: 200,
    resizeMode: 'contain',
    marginVertical: 8,
  },
});

export default Gallery;
