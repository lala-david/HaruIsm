import axios from 'axios';
import React, {useState, useEffect, useCallback} from 'react';
import {View, Text, TextInput, Button, Alert, StyleSheet} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import DateTimePicker from '@react-native-community/datetimepicker';
import {RootStackParamList} from '../../types/types';
import {StackNavigationProp} from '@react-navigation/stack';
import {RouteProp} from '@react-navigation/native';

type DailyScreenNavigationProp = StackNavigationProp<
  RootStackParamList,
  'Daily'
>;

type DailyProps = {
  navigation: DailyScreenNavigationProp;
  route: RouteProp<RootStackParamList, 'Daily'>;
};

const API_SERVER_URL = 'http://10.0.2.2:3000';

const Daily: React.FC<DailyProps> = ({navigation, route}) => {
  const [contentText, setContentText] = useState('');
  const [titleText, setTitleText] = useState(''); // 제목 추가
  const [date, setDate] = useState(new Date());
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [generateCount, setGenerateCount] = useState(0);

  const handleOpenGallery = () => {
    const selectedDateTag = `${date.getFullYear()}-${
      date.getMonth() + 1
    }-${date.getDate()}`;
    navigation.navigate('Gallery', {tag: selectedDateTag});
  };

  const {date: propDate} = route.params;

  useEffect(() => {
    if (propDate) {
      setDate(new Date(propDate));
    }
  }, [propDate]);

  const loadStoredData = useCallback(async () => {
    try {
      const dateString = `${date.getFullYear()}-${String(
        date.getMonth() + 1,
      ).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
      const value = await AsyncStorage.getItem(dateString);

      if (!value) {
        setTitleText('');
        setContentText('');
        return;
      }

      const storedData = JSON.parse(value);
      if (!storedData) {
        setTitleText('');
        setContentText('');
        return;
      }

      setTitleText(storedData.title || '');
      setContentText(storedData.content || '');
    } catch (error) {
      console.error('Error loading stored data:', error);
    }
  }, [date]);

  useEffect(() => {
    loadStoredData();
  }, [loadStoredData]);

  const onChangeDate = async (event: any, selectedDate?: Date) => {
    setShowDatePicker(false);
    if (selectedDate) {
      await handleSave();
      setDate(selectedDate);
    }
  };

  const handleSave = async () => {
    try {
      const dateString = `${date.getFullYear()}-${String(
        date.getMonth() + 1,
      ).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
      await AsyncStorage.setItem(
        dateString,
        JSON.stringify({title: titleText, content: contentText}),
      );
      await loadStoredData();
      console.log('Content saved');
    } catch (e) {
      console.error(e);
    }
  };

  const handleDrawEmotion = async () => {
    if (generateCount >= 5) {
      Alert.alert(
        '그림 생성 횟수 초과',
        '당일 그림은 더 이상 생성할 수 없습니다.',
      );
      return;
    }
    try {
      const response = await axios.post(`${API_SERVER_URL}/generate-image`, {
        text: contentText,
        model: 1,
      });

      if (response.status === 200) {
        const data = response.data;
        const generatedImage = data.image;
        const selectedDateTag = `${date.getFullYear()}-${
          date.getMonth() + 1
        }-${date.getDate()}`;
        await AsyncStorage.setItem(
          `image-${selectedDateTag}-${generateCount + 1}`,
          generatedImage,
        );
        navigation.navigate('GeneratedImage', {image: generatedImage});
        setGenerateCount(prevCount => prevCount + 1);
      } else {
        console.error(`Error response status: ${response.status}`);
      }
    } catch (error) {
      console.error('Error fetching image:', error);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.dateText}>{date.toISOString().split('T')[0]}</Text>
      <Button title="날짜 선택" onPress={() => setShowDatePicker(true)} />
      {showDatePicker && (
        <DateTimePicker
          value={date}
          mode="date"
          display="default"
          onChange={onChangeDate}
          maximumDate={new Date()}
        />
      )}
      <TextInput
        style={styles.titleInput}
        onChangeText={setTitleText}
        value={titleText}
        maxLength={50}
        placeholder="제목을 입력해주세요"
      />
      <TextInput
        style={styles.input}
        onChangeText={setContentText}
        value={contentText}
        maxLength={80}
        multiline={true}
      />
      <Button title="일기 저장" onPress={handleSave} />
      <View style={styles.emotionButton}>
        <Button title="그림 생성" onPress={handleDrawEmotion} />
        <View style={styles.galleryButton}>
          <Button title="갤러리" onPress={handleOpenGallery} />
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 16,
  },
  emotionButton: {
    marginTop: 10,
  },
  dateText: {
    fontSize: 20,
    marginBottom: 8,
  },
  titleInput: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 8,
  },
  input: {
    height: 80,
    borderColor: 'gray',
    borderWidth: 1,
    textAlignVertical: 'top',
    marginBottom: 16,
  },
  galleryButton: {
    marginTop: 10,
  },
});

export default Daily;
